script that prints the absolute path name
 of the current working director
Task 0. Where am I?
